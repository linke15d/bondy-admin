import axios, {
  AxiosInstance,
  InternalAxiosRequestConfig,
  AxiosRequestHeaders,
  AxiosResponse,
  AxiosError
} from 'axios'

import { config } from './config'

import { ElMessage, ElLoading } from 'element-plus'
import { resetRouter } from '@/router'
import { getToken, removeSession, clearStorage } from '@/utils/auth.util'
import { useTagsViewStore } from '@/store/modules/tagsView'

const tagsViewStore = useTagsViewStore()

const { base_url } = config

const { VITE_API_BASEURL } = import.meta.env
export const PATH_URL = base_url[import.meta.env.VITE_API_BASEPATH]

let loading: any

function startLoading() {
  loading = ElLoading.service({
    lock: true,
    text: '加载中……',
    background: 'rgba(0, 0, 0, 0.7)'
  })
}
function endLoading() {
  loading.close()
}

let needLoadingRequestCount = 0
export function showFullScreenLoading() {
  if (needLoadingRequestCount === 0) {
    startLoading()
  }
  needLoadingRequestCount++
}

export function tryHideFullScreenLoading() {
  if (needLoadingRequestCount <= 0) return
  needLoadingRequestCount--
  if (needLoadingRequestCount === 0) {
    endLoading()
  }
}

// 创建axios实例
const service: AxiosInstance = axios.create({
  baseURL: VITE_API_BASEURL, // api 的 base_url
  timeout: config.request_timeout // 请求超时时间
})

// request拦截器
service.interceptors.request.use(
  (config: InternalAxiosRequestConfig) => {
    if (getToken()) {
      ;(config.headers as AxiosRequestHeaders)['Authorization'] = 'Bearer ' + getToken()
    }
    // get参数编码
    if (config.method === 'get' && config.params) {
      let url = config.url as string
      url += '?'
      const keys = Object.keys(config.params)
      for (const key of keys) {
        if (config.params[key] !== void 0 && config.params[key] !== null) {
          url += `${key}=${encodeURIComponent(config.params[key])}&`
        }
      }
      url = url.substring(0, url.length - 1)
      config.params = {}
      config.url = url
    }

    showFullScreenLoading()
    return config
  },
  (error: AxiosError) => {
    console.log('err', error)
    Promise.reject(error)
  }
)

// response 拦截器
service.interceptors.response.use(
  async (response: AxiosResponse<any>) => {
    tryHideFullScreenLoading()
    if (response.config.responseType === 'blob') {
      // 如果是文件流，直接过
      return response
    }

    const decryptedData = response.data

    if (decryptedData.success) {
      return decryptedData
    } else if (!decryptedData.success && decryptedData.code == 211) {
      return decryptedData
    } else if (decryptedData.code === '401') {
      tagsViewStore.delAllViews()
      resetRouter() // 重置静态路由表
      clearStorage()
      removeSession('routeList')
      setTimeout(() => {
        window.location.reload()
      }, 200)
      ElMessage.error(decryptedData.msg)
    } else {
      if (decryptedData.code) {
        ElMessage.error(decryptedData.msg)
      }
      return decryptedData
    }
  },
  (error: AxiosError | any) => {
    tryHideFullScreenLoading()
    console.log(error)
    let { message, response } = error

    if (message == 'Network Error') {
      message = '后端接口连接异常'
    } else if (message.includes('timeout')) {
      message = '系统接口请求超时'
    } else if (response?.status == '401') {
      tagsViewStore.delAllViews()
      resetRouter() // 重置静态路由表
      clearStorage()
      removeSession('routeList')

      setTimeout(() => {
        window.location.reload()
      }, 200)
      ElMessage.error('登陆过期，请重新登陆')
    } else {
      const data = response.data
      ElMessage.error(data.msg)
    }
    ElMessage.error(message)
    return Promise.reject(error)
  }
)

export { service }
