import type { RouteMeta } from 'vue-router'
import { Icon } from '@/components/Icon'
import { useI18n } from '@/hooks/web/useI18n'

export const useRenderMenuTitle = (stringLongMap: Record<string, any>) => {
  const renderMenuTitle = (meta: RouteMeta) => {
    const { t } = useI18n()
    const { title = 'Please set title', icon } = meta

    return icon ? (
      <>
        <Icon icon={meta.icon}></Icon>
        <span class="v-menu__title">{t(title as string)}</span>
        <span
          v-show={meta.title == '账户管理' && stringLongMap.cardApply}
          class="w-2 h-2 bg-[red] rounded-1 ml-1"
        ></span>
        <span
          v-show={
            meta.title == '支付管理' &&
            (stringLongMap.rechargeOrder ||
              stringLongMap.exchangeOrder ||
              stringLongMap.bankCardTranOrder ||
              stringLongMap.mainAccountOrder)
          }
          class="w-2 h-2 bg-[red] rounded-1 ml-1"
        ></span>
      </>
    ) : (
      <span class="v-menu__title flex items-center">
        {t(title as string)}
        <span
          v-show={meta.title == '银行卡申请' && stringLongMap.cardApply}
          class="px-1 py-[2px] rounded-md bg-[red] ml-1 text-[#fff] text-[12px]"
        >
          {stringLongMap.cardApply}
        </span>
        <span
          v-show={meta.title == '充币订单' && stringLongMap.rechargeOrder}
          class="px-1 py-[2px] rounded-md bg-[red] ml-1 text-[#fff] text-[12px]"
        >
          {stringLongMap.rechargeOrder}
        </span>
        <span
          v-show={meta.title == '换汇订单' && stringLongMap.exchangeOrder}
          class="px-1 py-[2px] rounded-md bg-[red] ml-1 text-[#fff] text-[12px]"
        >
          {stringLongMap.exchangeOrder}
        </span>
        <span
          v-show={meta.title == '银行卡转入转出' && stringLongMap.bankCardTranOrder}
          class="px-1 py-[2px] rounded-md bg-[red] ml-1 text-[#fff] text-[12px]"
        >
          {stringLongMap.bankCardTranOrder}
        </span>
        <span
          v-show={meta.title == '人工订单' && stringLongMap.mainAccountOrder}
          class="px-1 py-[2px] rounded-md bg-[red] ml-1 text-[#fff] text-[12px]"
        >
          {stringLongMap.mainAccountOrder}
        </span>
      </span>
    )
  }

  return {
    renderMenuTitle
  }
}
