<template>
  <ElDialog
    :model-value="dialogVisible"
    title="Google验证码"
    width="40%"
    center
    :close-on-click-modal="false"
    :close-on-press-escape="false"
    :show-close="isShowModal"
  >
    <div class="google-content">
      <strong class="p mb-3 block">为了账户安全，请绑定Google验证器用于登录二次验证。</strong>
      <strong class="p1 mb-4 block"
        >1.在手机上下载并安装“Google Authenticator(谷歌身份验证器)"APP</strong
      >
      <div class="downLoad flex justify-start mb-4">
        <div class="app mr-18px">
          <el-button type="primary" plain @click="toDownLoad('ios')">下载IOS版本</el-button>
        </div>
        <div class="app">
          <el-button type="success" plain @click="toDownLoad('android')">下载Android版本</el-button>
        </div>
      </div>
      <p class="p1 mb-1">2.在 Google验证器中添加您的XXX账号密钥：</p>
      <p class="p3 text-size-12px mb-4">
        操作方法：在Google验证器中，点击添加新账户—扫描下方二维码进行添加。
      </p>
      <div class="verify-code mb-4">
        <div class="p1 mt-3">
          <strong>二维码：</strong>
          <div class="qrCode mb-2">
            <vue-qrcode
              type="image/png"
              :value="googleCode"
              :width="180"
              :color="{ dark: '#000000ff', light: '#ffffffff' }"
            />
          </div>
        </div>
      </div>
      <p class="p1 mb-2">3.填写 Google验证码，完成绑定</p>
      <p class="p1 mb-2">Google验证码</p>
      <div class="w-260px">
        <el-input
          v-model="code"
          maxLength="6"
          @input="(value) => (code = value.replace(/[^0-9.]/g, ''))"
          placeholder="请输入Google验证码"
        />
      </div>
    </div>

    <template #footer>
      <el-row>
        <el-col class="flex justify-center mt-20px">
          <el-button class="ml-8" type="primary" @click="verify">绑定</el-button>
        </el-col>
      </el-row>
    </template>
  </ElDialog>
</template>

<script lang="ts" setup>
import { ref } from 'vue'
import { ElMessage } from 'element-plus'
import VueQrcode from 'vue-qrcode'
import { googleBind } from './service'
import { clearStorage, removeSession } from '@/utils/auth.util'
import { resetRouter } from '@/router'
// import { useRouter } from 'vue-router'

// const { replace } = useRouter()

const props: any = defineProps({
  // 是否关闭弹窗
  isShowModal: {
    type: Boolean,
    default: false
  },
  //谷歌验证二维码
  googleCode: {
    type: String,
    default: ''
  }
})

// 验证码
const code = ref('')

const dialogVisible = ref<Boolean>(false)

//绑定
const verify = async () => {
  try {
    const data = {
      code: code.value
    }

    if (!data.code) {
      ElMessage.error('请输入Google验证码')
      return
    }
    const ret = await googleBind(data)
    if (ret.success) {
      ElMessage.success('绑定成功，请重新登陆')
      dialogVisible.value = false
      resetRouter() // 重置静态路由表
      clearStorage()
      removeSession('routeList')

      setTimeout(() => {
        window.location.reload()
      }, 200)
    } else {
      ElMessage.error('验证失败')
    }
  } catch (e) {}
}
// 去下载链接
const toDownLoad = (type: string) => {
  if (type === 'ios') {
    window.open('https://apps.apple.com/cn/app/google-authenticator/id388497605')
  } else {
    window.open(
      'https://play.google.com/store/apps/details?id=com.google.android.apps.authenticator2&hl=zh&gl=US'
    )
  }
}

// 开启弹窗
const openModal = () => {
  dialogVisible.value = true
}

// 暴露方法
defineExpose({
  openModal
})
</script>
