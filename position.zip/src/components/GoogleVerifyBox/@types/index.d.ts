export type GoogleParams={
  id: string
  googleEnable: boolean
  secretKey: string
  secretKeyUrl: string
  otpQrCode: string
}