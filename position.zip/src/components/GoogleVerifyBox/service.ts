import request from '@/config/axios'

/**
 * 是否绑定谷歌秘钥
 * @param data
 * @returns
 */
export const googleInfo = (): Promise<IResp> => {
  return request.post({ url: '/api/googleAuth/exist' })
}

/**
 * 绑定谷歌key
 * @param data
 * @returns
 */
export const googleBind = (data): Promise<IResp> => {
  return request.post({ url: '/api/googleAuth/bind', data })
}

/**
 * 获取谷歌key二维码
 * @param data
 * @returns
 */
export const googleQRCode = (): Promise<IResp> => {
  return request.post({ url: '/api/googleAuth/QRCode' })
}
