//清仓类型
export const closeTypeFormat = (type) => {
  switch (type) {
    case 'CLOSE':
      return {
        text: '平仓',
        type: 'success'
      }
    case 'FORCE':
      return {
        text: '爆仓',
        type: 'danger'
      }
    case 'LIGHTEN_UP':
      return {
        text: '⾃动减仓',
        type: 'warning'
      }
    case 'NORMAL':
      return {
        text: '正常',
        type: 'primary'
      }
    default:
      return {
        text: '未知类型',
        type: 'info'
      }
  }
}
//交易类型
export const sideFormat = (type) => {
  switch (type) {
    case 'BUY':
      return {
        text: '买入',
        type: 'success'
      }
    case 'SELL':
      return {
        text: '平仓',
        type: 'danger'
      }
    default:
      return {
        text: '未知类型',
        type: 'info'
      }
  }
}
//保证金模式
export const marginTypeFormat = (type) => {
  switch (type) {
    case 'ISOLATED':
      return {
        text: '逐仓',
        type: 'success'
      }
    case 'CROSSED':
      return {
        text: '全仓',
        type: 'danger'
      }
    default:
      return {
        text: '未知',
        type: 'info'
      }
  }
}

//合约类型
export const positionSideFormat = (type) => {
  switch (type) {
    case 'LONG':
      return {
        text: '做多',
        type: 'success'
      }
    case 'SHORT':
      return {
        text: '做空',
        type: 'danger'
      }
    case 'BOTH':
      return {
        text: '单一持仓',
        type: 'danger'
      }
    default:
      return {
        text: '未知类型',
        type: 'info'
      }
  }
}

//格式化金额
export const formatAmount = (amount) => {
  if (amount) {
    amount = Number(amount)
    if (amount >= 1000) {
      let divisor = 1000
      let formattedAmount = `${(amount / divisor).toFixed(3)}K`
      return formattedAmount
    } else {
      return amount.toFixed(3)
    }
  }
}
//格式化长地址 xxxxxxxx...xxxxxxxx
export const formatAddress = (address) => {
  if (address)
    return `${address.substring(0, 8)}...${address.substring(address.length - 8, address.length)}`
}

//小数保留位数
export const numberFormat = (num, digits) => {
  num = num ? Number(num) : 0
  return (Math.floor(num * 1000000) / 1000000).toFixed(digits)
}
