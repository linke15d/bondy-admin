import request from '@/config/axios'

//登录
export const loginApi = (data) => {
  return request.post({ url: '/api/login', data })
}

/**
 * 修改用户登录密码
 * @param data
 * @returns
 */
export const changePwd = (data): Promise<IResp> => {
  return request.post({ url: '/api/changepassword', data })
}
