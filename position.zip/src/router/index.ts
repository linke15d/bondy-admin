import { createRouter, createWebHashHistory } from 'vue-router'
import type { RouteRecordRaw } from 'vue-router'
import type { App } from 'vue'
import {
  Layout
  // getParentLayout
} from '@/utils/routerHelper'

export const constantRouterMap: AppRouteRecordRaw[] = [
  {
    path: '/',
    component: Layout,
    redirect: '/dashboard/analysis',
    name: 'Root',
    meta: {
      hidden: true
    }
  },
  {
    path: '/redirect',
    component: Layout,
    name: 'Redirect',
    children: [
      {
        path: '/redirect/:path(.*)',
        name: 'Redirect',
        component: () => import('@/views/Redirect/Redirect.vue'),
        meta: {}
      }
    ],
    meta: {
      hidden: true,
      noTagsView: true
    }
  },
  {
    path: '/login',
    component: () => import('@/views/Login/Login.vue'),
    name: 'Login',
    meta: {
      hidden: true,
      title: '登陆',
      noTagsView: true
    }
  },
  {
    path: '/404',
    component: () => import('@/views/Error/404.vue'),
    name: 'NoFind',
    meta: {
      hidden: true,
      title: '404',
      noTagsView: true
    }
  }
]

export const asyncRouterMap: AppRouteRecordRaw[] = [
  {
    path: '/dashboard',
    component: Layout,
    redirect: '/dashboard/analysis',
    name: 'Dashboard',
    meta: {
      title: '首页',
      icon: ''
    },
    children: [
      {
        path: 'analysis',
        component: () => import('@/views/Dashboard/Analysis.vue'),
        name: 'Analysis',
        meta: {
          title: '首页',
          icon: 'tabler:home-filled',
          noCache: true,
          affix: true
        }
      }
    ]
  },
  {
    path: '/binance',
    component: Layout,
    redirect: '/binance/account',
    name: 'Binance',
    meta: {
      title: '币安账号',
      icon: 'token:binance-smart-chain',
    },
    children: [
      {
        path: 'account',
        component: () => import('@/views/BinanceAccount/Account.vue'),
        name: 'Account',
        meta: {
          title: '币安账号',
          icon: 'token:binance-smart-chain',
        }
      }
    ]
  },
  {
    path: '/three',
    component: Layout,
    redirect: '/three/user',
    name: 'Three',
    meta: {
      title: '三方会员',
      icon: 'clarity:user-solid'
    },
    children: [
      {
        path: 'user',
        component: () => import('@/views/ThreeUser/User.vue'),
        name: 'User',
        meta: {
          title: '三方会员',
          icon: 'clarity:user-solid',
        }
      }
    ]
  },
  {
    path: '/position',
    component: Layout,
    redirect: '/position/monitor',
    name: 'Position',
    meta: {
      title: '仓位监控',
      icon: 'pajamas:monitor'
    },
    children: [
      {
        path: 'monitor',
        component: () => import('@/views/Monitor/Monitor.vue'),
        name: 'Monitor',
        meta: {
          title: '仓位监控',
          icon: 'pajamas:monitor',
        }
      }
    ]
  },
  {
    path: '/tradingPairs',
    component: Layout,
    redirect: '/TradingPairs',
    name: 'TradingPairs',
    meta: {
      title: '交易对列表',
      icon: 'simple-icons:tradingview'
    },
    children: [
      {
        path: 'list',
        component: () => import('@/views/TradingPairs/TradingPairs.vue'),
        name: 'TradingPairsList',
        meta: {
          title: '交易对列表',
          icon: 'simple-icons:tradingview',
        }
      }
    ]
  },
  {
    path: '/trans',
    component: Layout,
    redirect: '/trans/transDetails',
    name: 'Trans',
    meta: {
      title: '币安交易明细',
      icon: 'hugeicons:bitcoin-transaction'
    },
    children: [
      {
        path: 'transDetails',
        component: () => import('@/views/TransDetails/TransDetails.vue'),
        name: 'TransDetails',
        meta: {
          title: '币安交易明细',
          icon: 'hugeicons:bitcoin-transaction',
        }
      }
    ]
  },
  {
    path: '/global',
    component: Layout,
    redirect: '/global/parameters',
    name: 'Global',
    meta: {
      title: '全局参数',
      icon: 'ant-design:global-outlined'
    },
    children: [
      {
        path: 'parameters',
        component: () => import('@/views/Parameters/Parameters.vue'),
        name: 'Parameters',
        meta: {
          title: '全局参数',
          icon: 'ant-design:global-outlined',
        }
      }
    ]
  }
]

const router = createRouter({
  history: createWebHashHistory(),
  strict: true,
  routes: constantRouterMap as RouteRecordRaw[],
  scrollBehavior: () => ({ left: 0, top: 0 })
})

export const resetRouter = (): void => {
  const resetWhiteNameList = ['Redirect', 'Login', 'NoFind', 'Root']
  router.getRoutes().forEach((route) => {
    const { name } = route
    if (name && !resetWhiteNameList.includes(name as string)) {
      router.hasRoute(name) && router.removeRoute(name)
    }
  })
}

export const setupRouter = (app: App<Element>) => {
  app.use(router)
}

export default router
