<template>
  <div class="p-2">
    <ElCard class="mb-4">
      <el-row :gutter="20">
        <el-col :span="5">
          <el-form-item label="时间" size="small">
            <el-date-picker
              v-model="selectionDate"
              type="daterange"
              range-separator="至"
              start-placeholder="开始时间"
              end-placeholder="结束时间"
              format="YYYY-MM-DD"
              value-format="YYYY-MM-DD"
              @change="dateChange"
            />
          </el-form-item>
        </el-col>

        <el-col :span="5">
          <el-form-item label="跟单开关" size="small">
            <el-popconfirm :title="switchTitle" @confirm="confirm" @cancel="cancel">
              <template #reference>
                <el-switch
                  v-model="switchVal"
                  @change="onSwitchChange"
                  style="--el-switch-on-color: #13ce66; --el-switch-off-color: #ff4949"
                />
              </template>
            </el-popconfirm>
          </el-form-item>
        </el-col>
      </el-row>

      <el-row :gutter="20">
        <el-col :span="5">
          <el-form-item>
            <ElButton type="primary" size="small" @click="onSearch">搜索</ElButton>
            <ElButton size="small" @click="onReset">重置</ElButton>
          </el-form-item>
        </el-col>
      </el-row>
    </ElCard>
    <p class="my-2 text-base">币安统计</p>
    <ElRow :gutter="20" :class="prefixCls">
      <ElCol :xl="6" :lg="6" :md="12" :sm="12" :xs="24">
        <ElCard class="mb-20px">
          <ElSkeleton :loading="loading" animated :rows="2">
            <template #default>
              <div :class="`${prefixCls}__item flex justify-between h-34`">
                <div>
                  <div
                    :class="`${prefixCls}__item--icon ${prefixCls}__item--peoples p-16px inline-block rounded-6px`"
                  >
                    <Icon icon="mdi:account-credit-card" :size="50" class="!text-green-500" />
                  </div>
                </div>
                <div class="flex flex-col justify-between">
                  <div :class="`${prefixCls}__item--text text-16px text-gray-500 text-right`">
                    币安总资产
                  </div>
                  <div class="flex items-center justify-end">
                    <span>账号数：</span>
                    <span class="text-xl font-bold text-right">
                      {{ binanceData.accountSize ? binanceData.accountSize : 0 }}
                    </span>
                  </div>
                  <div class="flex items-center justify-end">
                    <span>总余额：</span>
                    <span class="text-xl font-bold text-right">
                      {{ binanceData.accountAmount ? binanceData.accountAmount : 0 }}
                    </span>
                  </div>
                </div>
              </div>
            </template>
          </ElSkeleton>
        </ElCard>
      </ElCol>
      <ElCol :xl="6" :lg="6" :md="12" :sm="12" :xs="24">
        <ElCard class="mb-20px">
          <ElSkeleton :loading="loading" animated :rows="2">
            <template #default>
              <div :class="`${prefixCls}__item flex justify-between h-34`">
                <div>
                  <div
                    :class="`${prefixCls}__item--icon ${prefixCls}__item--peoples p-16px inline-block rounded-6px`"
                  >
                    <Icon icon="fontisto:wallet" :size="50" class="text-sky-400" />
                  </div>
                </div>
                <div class="flex flex-col justify-between">
                  <div :class="`${prefixCls}__item--text text-16px text-gray-500 text-right`">
                    币安总赢亏
                  </div>

                  <div class="flex items-center justify-end">
                    <span>历史盈亏：</span>
                    <span
                      class="text-xl font-bold text-right"
                      :class="[
                        binanceData.realizedProfit < 0
                          ? 'text-[var(--el-color-danger)]'
                          : 'text-[var(--el-color-success)]'
                      ]"
                    >
                      {{
                        binanceData.realizedProfit
                          ? binanceData.realizedProfit < 0
                            ? binanceData.realizedProfit
                            : `+${binanceData.realizedProfit}`
                          : 0
                      }}
                    </span>
                  </div>

                  <div class="flex items-center justify-end">
                    <span>累计手续费：</span>
                    <span class="text-xl font-bold text-right">
                      {{ binanceData.commission ? binanceData.commission : 0 }}
                    </span>
                  </div>
                </div>
              </div>
            </template>
          </ElSkeleton>
        </ElCard>
      </ElCol>
      <ElCol :xl="6" :lg="6" :md="12" :sm="12" :xs="24">
        <ElCard class="mb-20px">
          <ElSkeleton :loading="loading" animated :rows="2">
            <template #default>
              <div :class="`${prefixCls}__item flex justify-between h-34`">
                <div>
                  <div
                    :class="`${prefixCls}__item--icon ${prefixCls}__item--peoples p-16px inline-block rounded-6px`"
                  >
                    <Icon icon="bxs:collection" :size="50" class="text-pink-400" />
                  </div>
                </div>
                <div class="flex flex-col justify-between">
                  <div :class="`${prefixCls}__item--text text-16px text-gray-500 text-right`">
                    币安持仓
                  </div>
                  <div class="flex items-center justify-end">
                    <span>总数：</span>
                    <span class="text-xl font-bold text-right">
                      {{ binanceData.positionSize ? binanceData.positionSize : 0 }}
                    </span>
                  </div>
                  <div class="flex items-center justify-end">
                    <span>金额：</span>
                    <span class="text-xl font-bold text-right">
                      {{ binanceData.positionAmount ? binanceData.positionAmount : 0 }}
                    </span>
                  </div>
                  <div class="flex items-center justify-end">
                    <span>盈亏：</span>
                    <span
                      class="text-xl font-bold text-right"
                      :class="[
                        binanceData.profit < 0
                          ? 'text-[var(--el-color-danger)]'
                          : 'text-[var(--el-color-success)]'
                      ]"
                    >
                      {{
                        binanceData.profit
                          ? binanceData.profit < 0
                            ? binanceData.profit
                            : `+${binanceData.profit}`
                          : 0
                      }}
                    </span>
                  </div>
                </div>
              </div>
            </template>
          </ElSkeleton>
        </ElCard>
      </ElCol>

      <ElCol :xl="6" :lg="6" :md="12" :sm="12" :xs="24">
        <ElCard class="mb-20px !bg-gray-300">
          <ElSkeleton :loading="loading" animated :rows="2">
            <template #default>
              <div :class="`${prefixCls}__item flex justify-between h-34`">
                <div>
                  <div
                    :class="`${prefixCls}__item--icon ${prefixCls}__item--peoples p-16px inline-block rounded-6px`"
                  >
                    <Icon icon="uil:bill" :size="50" class="text-yellow-500" />
                  </div>
                </div>
                <div class="flex flex-col justify-between">
                  <div :class="`${prefixCls}__item--text text-16px text-gray-500 text-right`">
                    跟单
                  </div>
                  <div class="flex items-center justify-end">
                    <span>数量：</span>
                    <span class="text-xl font-bold text-right">
                      {{ binanceData.orderSize ? binanceData.orderSize : 0 }}
                    </span>
                  </div>
                  <div class="flex items-center justify-end">
                    <span>金额：</span>
                    <span class="text-xl font-bold text-right">
                      {{ binanceData.orderAmount ? binanceData.orderAmount : 0 }}
                    </span>
                  </div>
                </div>
              </div>
            </template>
          </ElSkeleton>
        </ElCard>
      </ElCol>
    </ElRow>
    <p class="my-2 text-base">三方统计</p>
    <ElRow :gutter="20" :class="prefixCls">
      <ElCol :xl="6" :lg="6" :md="12" :sm="12" :xs="24">
        <ElCard class="mb-20px">
          <ElSkeleton :loading="loading" animated :rows="2">
            <template #default>
              <div :class="`${prefixCls}__item flex justify-between h-34`">
                <div>
                  <div
                    :class="`${prefixCls}__item--icon ${prefixCls}__item--peoples p-16px inline-block rounded-6px`"
                  >
                    <Icon icon="wpf:add-user" :size="50" class="!text-green-500" />
                  </div>
                </div>
                <div class="flex flex-col justify-between">
                  <div :class="`${prefixCls}__item--text text-16px text-gray-500 text-right`">
                    总会员数
                  </div>
                  <span class="text-xl font-bold text-right">
                    {{ summaryData.userIds ? summaryData.userIds : 0 }}
                  </span>
                </div>
              </div>
            </template>
          </ElSkeleton>
        </ElCard>
      </ElCol>
      <ElCol :xl="6" :lg="6" :md="12" :sm="12" :xs="24">
        <ElCard class="mb-20px">
          <ElSkeleton :loading="loading" animated :rows="2">
            <template #default>
              <div :class="`${prefixCls}__item flex justify-between h-34`">
                <div>
                  <div
                    :class="`${prefixCls}__item--icon ${prefixCls}__item--peoples p-16px inline-block rounded-6px`"
                  >
                    <Icon icon="fluent-mdl2:quantity" :size="50" class="text-blue-400" />
                  </div>
                </div>
                <div class="flex flex-col justify-between">
                  <div :class="`${prefixCls}__item--text text-16px text-gray-500 text-right`">
                    总持仓数
                  </div>
                  <span class="text-xl font-bold text-right">
                    {{ summaryData.positionCou ? summaryData.positionCou : 0 }}
                  </span>
                </div>
              </div>
            </template>
          </ElSkeleton>
        </ElCard>
      </ElCol>
      <ElCol :xl="6" :lg="6" :md="12" :sm="12" :xs="24">
        <ElCard class="mb-20px">
          <ElSkeleton :loading="loading" animated :rows="2">
            <template #default>
              <div :class="`${prefixCls}__item flex justify-between h-34`">
                <div>
                  <div
                    :class="`${prefixCls}__item--icon ${prefixCls}__item--peoples p-16px inline-block rounded-6px`"
                  >
                    <Icon icon="solar:money-bag-bold" :size="50" class="text-red-400" />
                  </div>
                </div>
                <div class="flex flex-col justify-between">
                  <div :class="`${prefixCls}__item--text text-16px text-gray-500 text-right`">
                    总赢亏
                  </div>
                  <span
                    class="text-xl font-bold text-right"
                    :class="[
                      summaryData.profitLoss < 0
                        ? 'text-[var(--el-color-danger)]'
                        : 'text-[var(--el-color-success)]'
                    ]"
                  >
                    {{ summaryData.profitLoss ? summaryData.profitLoss : 0 }}
                  </span>
                </div>
              </div>
            </template>
          </ElSkeleton>
        </ElCard>
      </ElCol>
    </ElRow>
  </div>
</template>

<script lang="ts" setup>
import { reactive, ref, onMounted } from 'vue'
import { useDesign } from '@/hooks/web/useDesign'
import { dataOverview, follow, followStatus } from './service'
import { ElMessage } from 'element-plus'
import { summary } from '../ThreeUser/service'

import dayjs from 'dayjs'

const today = dayjs().format('YYYY-MM-DD')

const { getPrefixCls } = useDesign()
const prefixCls = getPrefixCls('panel')

const form = reactive({
  startTime: today,
  endTime: today
})

const selectionDate = ref([today, today])
const loading = ref(true)
const binanceData: any = ref({})
const switchVal = ref(true)
const switchTitle = ref('')
const summaryData: any = ref({})

//三方统计
const getSummary = async () => {
  const params = Object.assign({ ...form })
  for (const i in params) {
    if (params[i] === '' || params[i] === null || params[i] === undefined) {
      delete params[i]
    }
  }
  const res = await summary(params)
  summaryData.value = res.data
}

//跟单开关状态
const getFollowStatus = async () => {
  const res = await followStatus()
  switchVal.value = res.data.status
}

//跟单开关
const confirm = async () => {
  await follow({ enabled: switchVal.value })
  ElMessage.success('操作成功')
  getFollowStatus()
}
const cancel = () => {
  switchVal.value = !switchVal.value
}
const onSwitchChange = (val) => {
  switchTitle.value = val ? '确定开启跟单吗？' : '确定取消跟单吗？'
}

//选择时间
const dateChange = (val) => {
  form.startTime = val ? val[0] : ''
  form.endTime = val ? val[1] : ''
}

// 获取统计数据
const getCount = async () => {
  loading.value = false
  const params = Object.assign({ ...form })
  for (const i in params) {
    if (params[i] === '') {
      delete params[i]
    }
  }
  const res = await dataOverview(params)
  binanceData.value = res.data
}

const onSearch = () => {
  getCount()
  getSummary()
}

const onReset = () => {
  selectionDate.value = [today, today]
  form.startTime = today
  form.endTime = today
  getCount()
  getSummary()
}

onMounted(() => {
  getSummary()
  getCount()
  getFollowStatus()
})
</script>
