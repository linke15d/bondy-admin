import request from '@/config/axios'

//统计
export const dataOverview = (data): Promise<IResp> => {
  return request.post({ url: '/api/dataOverview/binance', data })
}
//跟单开关
export const follow = (data): Promise<IResp> => {
  return request.post({ url: '/api/client/follow', data })
}
//跟单开关状态
export const followStatus = (): Promise<IResp> => {
  return request.post({ url: '/api/client/followStatus' })
}
