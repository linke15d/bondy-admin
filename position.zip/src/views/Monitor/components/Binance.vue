<template>
  <el-form size="small">
    <ElCard>
      <el-row :gutter="20">
        <el-col :span="5">
          <el-form-item label="创建时间" size="small">
            <el-date-picker
              v-model="selectionDate"
              type="daterange"
              range-separator="至"
              start-placeholder="开始时间"
              end-placeholder="结束时间"
              format="YYYY-MM-DD"
              value-format="YYYY-MM-DD"
              @change="dateChange"
            />
          </el-form-item>
        </el-col>

        <el-col :span="4">
          <el-form-item label="账号名称" size="small">
            <el-select v-model="form.accountId" class="w-full" placeholder="请选择账号名称">
              <el-option label="全部" value="" />
              <el-option
                v-for="(item, index) in binanceAccountList"
                :key="index"
                :label="item.accountId"
                :value="item.id"
              />
            </el-select>
          </el-form-item>
        </el-col>

        <el-col :span="4">
          <el-form-item label="状态" size="small">
            <el-select v-model="form.closeStatus" class="w-full">
              <el-option label="全部" :value="null" />
              <el-option label="正常" :value="false" />
              <el-option label="已平仓" :value="true" />
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="5">
          <el-form-item>
            <ElButton type="primary" size="small" @click="onSearch">搜索</ElButton>
            <ElButton size="small" @click="onReset">重置</ElButton>
          </el-form-item>
        </el-col>
      </el-row>
    </ElCard>

    <ElCard class="my-5">
      <ElTable :data="tableList" ref="refTable" style="width: 100%" size="small">
        <ElTableColumn label="币安仓位ID" prop="positionId" align="center" />
        <ElTableColumn label="交易对" prop="symbol" align="center" width="100" />
        <ElTableColumn
          label="账号名称"
          prop="accountName"
          align="center"
          show-overflow-tooltip
          width="150"
        >
          <template #default="{ row }">
            <span>{{ row.accountName ? row.accountName : '--' }}</span>
          </template>
        </ElTableColumn>
        <ElTableColumn prop="positionSide" label="合约类型" align="center">
          <template #default="{ row }">
            <el-tag :type="positionSideFormat(row.positionSide).type">
              {{ positionSideFormat(row.positionSide).text }}
            </el-tag>
          </template>
        </ElTableColumn>
        <ElTableColumn label="保证金模式" prop="marginType" align="center">
          <template #default="{ row }">
            <el-tag :type="marginTypeFormat(row.marginType).type">
              {{ marginTypeFormat(row.marginType).text }}
            </el-tag>
          </template>
        </ElTableColumn>
        <ElTableColumn label="杠杆倍数" prop="leverage" align="center" />
        <ElTableColumn label="开仓价" prop="entryPrice" align="center" />
        <ElTableColumn label="市价" prop="marketPrice" align="center" />
        <ElTableColumn label="补仓次数" prop="buyCount" align="center">
          <template #default="{ row }">
            <span>{{ row.buyCount ? row.buyCount : 0 }}</span>
          </template>
        </ElTableColumn>
        <ElTableColumn label="减仓次数" prop="sellCount" align="center">
          <template #default="{ row }">
            <span>{{ row.sellCount ? row.sellCount : 0 }}</span>
          </template>
        </ElTableColumn>
        <!-- <ElTableColumn label="仓位余额" prop="availableNotional" align="center" width="120" /> -->
        <ElTableColumn label="保证金" prop="margin" align="center">
          <template #default="{ row }">
            <span>{{ row.margin ? row.margin : '0.00' }}</span>
          </template>
        </ElTableColumn>

        <ElTableColumn label="持币数" prop="positionAmt" align="center">
          <template #default="{ row }">
            <span>{{ row.positionAmt ? row.positionAmt : '0.00' }}</span>
          </template>
        </ElTableColumn>
        <ElTableColumn label="开仓时间" prop="startTime" align="center" width="180" />
        <ElTableColumn label="当前盈亏" align="center" width="120">
          <template #default="{ row }">
            <p
              :class="[
                row.unrealizedProfit >= 0
                  ? 'text-[var(--el-color-success)]'
                  : 'text-[var(--el-color-danger)]'
              ]"
            >
              {{ row.unrealizedProfit ? row.unrealizedProfit : 0.0 }}
            </p>
          </template>
        </ElTableColumn>
        <ElTableColumn label="状态" align="center">
          <template #default="{ row }">
            <p
              :class="[
                row.closeStatus ? 'text-[var(--el-color-danger)]' : 'text-[var(--el-color-success)]'
              ]"
            >
              {{ row.closeStatus ? '已平仓' : '正常' }}
            </p>
          </template>
        </ElTableColumn>
        <ElTableColumn label="备注" prop="closeRemark" align="center" width="150">
          <template #default="{ row }">
            <span>{{ row.closeRemark ? row.closeRemark : '--' }}</span>
          </template>
        </ElTableColumn>
        <ElTableColumn label="操作" fixed="right" align="center">
          <template #default="{ row }">
            <el-popconfirm title="确认一键平仓吗?" @confirm="onClosing(row)">
              <template #reference>
                <ElButton type="success" size="small" v-if="!row.closeStatus"> 一键平仓</ElButton>
              </template>
            </el-popconfirm>
            <p v-if="row.closeStatus">--</p>
          </template>
        </ElTableColumn>
      </ElTable>
    </ElCard>

    <ElCard class="box-card">
      <el-pagination
        :current-page="form.pageNum + 1"
        small
        v-model:page-size="form.pageSize"
        :page-sizes="[10, 20, 50, 100]"
        background
        layout="total, sizes, prev, pager, next, jumper"
        :total="totalPages"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </ElCard>
  </el-form>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { positionQuery, positionClose } from '../service'
import { marginTypeFormat, positionSideFormat } from '@/utils/format'
import { ElButton, ElMessage } from 'element-plus'
import { accountList } from '../../BinanceAccount/service'

const form = reactive({
  pageNum: 0,
  pageSize: 10,
  accountId: '',
  crateTimeStart: '',
  closeStatus: null,
  crateTimeEnd: ''
})
const selectionDate = ref([])
const tableList = ref<any>([])
const totalPages = ref(0)
const binanceAccountList: any = ref([])
const refTable = ref()

//获取币安账号列表
const getAccountList = async () => {
  const res = await accountList({})
  binanceAccountList.value = res.data.list
}

//一键平仓
const onClosing = async (data) => {
  await positionClose({ id: data.id })
  ElMessage.success('操作成功')
  getMonitorQuery()
}

//选择时间
const dateChange = (val) => {
  form.crateTimeStart = val ? val[0] : ''
  form.crateTimeEnd = val ? val[1] : ''
}

// 选择每页显示条数
const handleSizeChange = (val: number) => {
  form.pageSize = val
  getMonitorQuery()
}
// 点击每一页
const handleCurrentChange = (val: number) => {
  form.pageNum = val - 1
  getMonitorQuery()
}

//获取列表
const getMonitorQuery = async () => {
  const params = Object.assign({ ...form })
  for (const i in params) {
    if (params[i] === '') {
      delete params[i]
    }
  }
  const res = await positionQuery(params)
  tableList.value = res.data.list
  totalPages.value = res.data.totalCount
}

const onSearch = () => {
  form.pageNum = 0
  getMonitorQuery()
}
const onReset = () => {
  selectionDate.value = []
  form.pageNum = 0
  form.pageSize = 10
  form.accountId = ''
  form.closeStatus = null
  form.crateTimeStart = ''
  form.crateTimeEnd = ''
  getMonitorQuery()
}

onMounted(() => {
  getAccountList()
  getMonitorQuery()
})
</script>
