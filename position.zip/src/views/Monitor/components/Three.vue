<template>
  <el-form size="small">
    <ElCard>
      <el-row :gutter="20">
        <el-col :span="5">
          <el-form-item label="创建时间" size="small">
            <el-date-picker
              v-model="selectionDate"
              type="daterange"
              range-separator="至"
              start-placeholder="开始时间"
              end-placeholder="结束时间"
              format="YYYY-MM-DD"
              value-format="YYYY-MM-DD"
              @change="dateChange"
            />
          </el-form-item>
        </el-col>

        <el-col :span="4">
          <el-form-item label="三方仓位ID" size="small">
            <el-input
              v-model="form.positionId"
              placeholder="请输入三方仓位ID"
              @input="(val) => (form.positionId = val.replace(/[^0-9]/g, ''))"
            ></el-input>
          </el-form-item>
        </el-col>

        <!-- <el-col :span="4">
          <el-form-item label="三方会员UID" size="small">
            <el-input
              v-model="form.userId"
              placeholder="请输入三方会员UID"
              @input="(val) => (form.userId = val.replace(/[^0-9]/g, ''))"
            ></el-input>
          </el-form-item>
        </el-col> -->

        <el-col :span="4">
          <el-form-item label="是否跟单" size="small">
            <el-select v-model="form.openPosition">
              <el-option label="全部" value="" />
              <el-option label="是" :value="true" />
              <el-option label="否" :value="false" />
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="5">
          <el-form-item>
            <ElButton type="primary" size="small" @click="onSearch">搜索</ElButton>
            <ElButton size="small" @click="onReset">重置</ElButton>
          </el-form-item>
        </el-col>
      </el-row>
    </ElCard>

    <ElCard class="my-5">
      <ElTable :data="tableList" ref="refTable" style="width: 100%" size="small">
        <ElTableColumn label="三方仓位ID" prop="positionId" align="center" />
        <ElTableColumn label="交易对" prop="symbolName" align="center" />
        <ElTableColumn label="三方会员UID" prop="userId" align="center" />
        <ElTableColumn prop="positionType" label="合约类型" align="center">
          <template #default="{ row }">
            <el-tag :type="row.positionType == 'SELL' ? 'danger' : 'success'">
              {{ row.positionType == 'SELL' ? '做空' : '做多' }}
            </el-tag>
          </template>
        </ElTableColumn>
        <ElTableColumn label="保证金模式" prop="marginType" align="center">
          <template #default="{ row }">
            <el-tag :type="marginTypeFormat(row.marginType).type">
              {{ marginTypeFormat(row.marginType).text }}
            </el-tag>
          </template>
        </ElTableColumn>
        <ElTableColumn label="杠杆倍数" prop="leverage" align="center" />
        <ElTableColumn label="开仓价" prop="holdPrice" align="center" />
        <ElTableColumn label="市价" prop="marketPrice" align="center" />
        <ElTableColumn label="补仓次数" prop="marginCou" align="center" />
        <ElTableColumn label="减仓次数" prop="lightenUp" align="center" />
        <!-- <ElTableColumn label="仓位余额" prop="margin" align="center" /> -->
        <ElTableColumn label="保证金" prop="margin" align="center">
          <template #default="{ row }">
            <span>{{ row.margin ? row.margin : '0.00' }}</span>
          </template>
        </ElTableColumn>
        <ElTableColumn label="持币数" prop="volume" align="center">
          <template #default="{ row }">
            <span>{{ row.volume ? row.volume : '0.00' }}</span>
          </template>
        </ElTableColumn>
        <ElTableColumn label="创建时间" prop="createTime" align="center" width="180" />
        <ElTableColumn label="当前盈亏" align="center">
          <template #default="{ row }">
            <p
              :class="[
                row.rlzPnl >= 0 ? 'text-[var(--el-color-success)]' : 'text-[var(--el-color-danger)]'
              ]"
            >
              {{ row.rlzPnl }}
            </p>
          </template>
        </ElTableColumn>
      </ElTable>
    </ElCard>

    <ElCard class="box-card">
      <el-pagination
        :current-page="form.pageNum + 1"
        small
        v-model:page-size="form.pageSize"
        :page-sizes="[10, 20, 50, 100]"
        background
        layout="total, sizes, prev, pager, next, jumper"
        :total="totalPages"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </ElCard>
  </el-form>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { monitorQuery } from '../service'
import { marginTypeFormat } from '@/utils/format'
import { ElButton } from 'element-plus'
import { useRoute } from 'vue-router'

const route = useRoute()

const form = reactive({
  pageNum: 0,
  pageSize: 10,
  positionId: '',
  userId: '',
  startTime: '',
  endTime: '',
  openPosition: true
})
const selectionDate = ref([])
const tableList = ref<any>([])
const totalPages = ref(0)

const refTable = ref()

//选择时间
const dateChange = (val) => {
  form.startTime = val ? val[0] : ''
  form.endTime = val ? val[1] : ''
}

// 选择每页显示条数
const handleSizeChange = (val: number) => {
  form.pageSize = val
  getMonitorQuery()
}
// 点击每一页
const handleCurrentChange = (val: number) => {
  form.pageNum = val - 1
  getMonitorQuery()
}

//获取列表
const getMonitorQuery = async () => {
  const params = Object.assign({ ...form })
  params.userId = !params.userId.length ? '' : Number(params.userId)
  params.positionId = !params.positionId.length ? '' : Number(params.positionId)
  for (const i in params) {
    if (params[i] === '') {
      delete params[i]
    }
  }
  const res = await monitorQuery(params)
  tableList.value = res.data.list
  totalPages.value = res.data.totalCount
}

const onSearch = () => {
  form.pageNum = 0
  getMonitorQuery()
}
const onReset = () => {
  selectionDate.value = []
  form.pageNum = 0
  form.pageSize = 10
  form.positionId = ''
  form.userId = ''
  form.startTime = ''
  form.endTime = ''
  form.openPosition = true
  getMonitorQuery()
}

onMounted(() => {
  if (route.query.userId) {
    form.userId = route.query.userId + ''
  }
  getMonitorQuery()
})
</script>
