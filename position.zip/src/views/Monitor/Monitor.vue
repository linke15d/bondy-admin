<template>
  <div>
    <el-tabs type="border-card" v-model="activeName">
      <el-tab-pane label="币安仓位" name="Binance">
        <Binance />
      </el-tab-pane>

      <el-tab-pane label="三方仓位" name="Three">
        <Three :userId="userId" />
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import Binance from './components/Binance.vue'
import Three from './components/Three.vue'

const route = useRoute()
const userId = ref()
const activeName = ref('Binance')

onMounted(() => {
  if (route.query.userId) {
    activeName.value = 'Three'
  }
})
</script>
