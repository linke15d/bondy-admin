import request from '@/config/axios'

// 三方仓位监控
export const monitorQuery = (data): Promise<IResp> => {
  return request.post({ url: '/api/position/monitor/query', data })
}
// 币安仓位监控
export const positionQuery = (data): Promise<IResp> => {
  return request.post({ url: '/api/binance/position/query', data })
}
// 一键平仓
export const positionClose = (data): Promise<IResp> => {
  return request.post({ url: '/api/binance/position/close', data })
}
