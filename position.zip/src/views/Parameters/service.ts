import request from '@/config/axios'

//列表查询
export const configQuery = (data): Promise<IResp> => {
  return request.post({ url: '/api/system/config/query', data })
}
//新增参数
export const configSave = (data): Promise<IResp> => {
  return request.post({ url: '/api/system/config/save', data })
}
//配置key列表
export const queryKeys = (): Promise<IResp> => {
  return request.post({ url: '/api/system/config/queryKeys' })
}
