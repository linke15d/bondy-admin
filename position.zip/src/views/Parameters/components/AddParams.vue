<template>
  <el-dialog
    :model-value="dialogVisible"
    :title="itemData.key ? '编辑配置' : '新增配置'"
    width="400"
    center
    :before-close="onClose"
  >
    <el-form :model="saveData" size="small" :rules="rules" label-width="80" ref="ruleFormRef">
      <el-form-item label="配置Key" prop="key">
        <el-select
          :disabled="itemData.key ? true : false"
          v-model="saveData.key"
          class="w-full"
          placeholder="请选择配置Key"
          @change="onChange"
        >
          <el-option
            v-for="(item, index) in keyList"
            :key="index"
            :label="item.value"
            :value="item.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="配置名称" prop="name">
        <el-input v-model="saveData.name" disabled placeholder="请输入配置名称" />
      </el-form-item>
      <el-form-item label="阀值" prop="limitValue">
        <el-input
          v-model="saveData.limitValue"
          oninput="value=value.replace(/[^0-9.]/g,'')"
          placeholder="请输入阀值"
        />
      </el-form-item>
      <el-form-item label="备注">
        <el-input v-model="saveData.remark" type="textarea" :rows="3" placeholder="请输入备注" />
      </el-form-item>
    </el-form>

    <template #footer>
      <el-button size="small" @click="onClose">取消</el-button>
      <el-button size="small" type="primary" @click="onSubmitData">确认</el-button>
    </template>
  </el-dialog>
</template>

<script setup lang="ts">
import { ref, watch } from 'vue'
import { ElMessage } from 'element-plus'
import { configSave, queryKeys } from '../service'

const emit = defineEmits(['close', 'success', 'getOrg'])
const props = defineProps({
  dialogVisible: {
    type: Boolean,
    default: false
  },
  itemData: {
    type: Object,
    default: {}
  }
})

const rules = ref({
  key: [{ required: true, message: '配置Key不能为空', trigger: ['blur', 'change'] }],
  name: [{ required: true, message: '配置名称不能为空', trigger: 'blur' }],
  limitValue: [{ required: true, message: '阀值不能为空', trigger: 'blur' }]
})

const ruleFormRef = ref()

const saveData = ref<any>({
  key: '',
  name: '',
  limitValue: '',
  remark: ''
})
const keyList: any = ref([])

//获取配置key
const getKeyList = async () => {
  const res = await queryKeys()
  keyList.value = res.data.list
}

//选择key
const onChange = (val) => {
  keyList.value.forEach((item) => {
    if (item.value === val) {
      saveData.value.name = item.key
    }
  })
}

watch(
  () => props.dialogVisible,
  (val) => {
    if (val) getKeyList()
  },
  { immediate: true, deep: true }
)

watch(
  () => props.itemData,
  (val) => {
    if (val && val.key) {
      saveData.value.key = val.key
      saveData.value.name = val.name
      saveData.value.limitValue = val.limitValue
      saveData.value.remark = val.remark
    } else {
      saveData.value = {
        key: '',
        name: '',
        limitValue: '',
        remark: ''
      }
    }
  },
  { immediate: true, deep: true }
)

const onSubmitData = async () => {
  await ruleFormRef.value.validate((vali, fields) => {
    if (!vali) {
      console.log('error submit!', fields)
    } else {
      try {
        let params: any = {}

        params = Object.assign({ ...saveData.value })

        for (const i in params) {
          if (params[i] === '' || params[i] === undefined || params[i] === null) {
            delete params[i]
          }
        }

        configSave(params).then((res) => {
          if (res.success) {
            ruleFormRef.value.resetFields()
            ElMessage.success('操作成功')
            emit('success')
            emit('close')
          }
        })
      } catch (error) {
        console.log(error)
      }
    }
  })
}

const onClose = () => {
  ruleFormRef.value.resetFields()
  emit('close')
}
</script>

<style>
.danger {
  .el-radio__input.is-checked .el-radio__inner {
    border-color: var(--el-color-danger);
    background: var(--el-color-danger);
  }
  .el-radio__input.is-checked + .el-radio__label {
    color: var(--el-color-danger);
  }
}
</style>
