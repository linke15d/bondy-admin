<template>
  <div class="p-2">
    <ElCard class="my-4">
      <el-row>
        <el-form-item>
          <el-button type="success" @click="onWrite(null)" size="small"> 新增配置 </el-button>
        </el-form-item>
      </el-row>

      <el-table size="small" ref="multipleTable" :data="tableList" style="width: 100%">
        <el-table-column prop="key" label="配置Key" align="center" />
        <el-table-column prop="name" label="配置名称" align="center" />
        <el-table-column prop="limitValue" label="阀值" align="center" />
        <el-table-column prop="remark" label="备注" align="center">
          <template #default="{ row }">
            <span>{{ row.remark ? row.remark : '--' }}</span>
          </template>
        </el-table-column>
        <el-table-column label="操作" align="center" fixed="right">
          <template #default="{ row }">
            <el-button type="warning" @click="onWrite(row)" size="small"> 编辑 </el-button>
          </template>
        </el-table-column>
      </el-table>
    </ElCard>

    <ElCard>
      <el-pagination
        :current-page="form.pageNum + 1"
        small
        v-model:page-size="form.pageSize"
        :page-sizes="[10, 20, 50, 100]"
        background
        layout="total, sizes, prev, pager, next, jumper"
        :total="totalPages"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </ElCard>

    <AddParams
      :itemData="itemData"
      :dialogVisible="dialogVisible"
      @close=";(dialogVisible = false), (itemData = {})"
      @success=";(dialogVisible = false), getList()"
    />
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { configQuery } from './service'
import AddParams from './components/AddParams.vue'

const tableList: any = ref([])
const form = reactive({
  pageNum: 0,
  pageSize: 10
})
const totalPages = ref(0)
const dialogVisible = ref(false)
const itemData = ref({})

//获取列表
const getList = async () => {
  const res = await configQuery(form)
  tableList.value = res.data.list
  totalPages.value = res.data.totalCount
}

// 选择每页显示条数
const handleSizeChange = (val: number) => {
  form.pageSize = val
  getList()
}
// 点击每一页
const handleCurrentChange = (val: number) => {
  form.pageNum = val - 1
  getList()
}

const onWrite = (data) => {
  dialogVisible.value = true
  itemData.value = data ? data : {}
}

onMounted(() => {
  getList()
})
</script>
