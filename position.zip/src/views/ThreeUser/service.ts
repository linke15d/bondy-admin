import request from '@/config/axios'

//三方会员列表查询
export const clientQuery = (data): Promise<IResp> => {
  return request.post({ url: '/api/client/query', data })
}
//三方会员修改参数
export const upParam = (data): Promise<IResp> => {
  return request.post({ url: '/api/client/upParam', data })
}
//三方会员修改批量参数
export const upBatchParam = (data): Promise<IResp> => {
  return request.post({ url: '/api/client/upBatchParam', data })
}
//统计
export const summary = (data): Promise<IResp> => {
  return request.post({ url: '/api/client/summary', data })
}
//累计盈亏详情
export const queryBalance = (data): Promise<IResp> => {
  return request.post({ url: '/api/client/queryBalance', data })
}
