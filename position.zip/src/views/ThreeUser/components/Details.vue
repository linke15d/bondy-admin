<template>
  <el-dialog
    :model-value="detailsVisible"
    title="盈亏记录"
    width="1200"
    center
    :before-close="close"
  >
    <el-table size="small" ref="multipleTable" :data="tableList" style="width: 100%">
      <el-table-column prop="positionId" label="三方仓位ID" align="center" />
      <el-table-column prop="marginType" label="保证金模式" align="center">
        <template #default="{ row }">
          <el-tag :type="row.marginType == 'ISOLATED' ? 'danger' : 'success'">
            {{ row.marginType == 'ISOLATED' ? '逐仓' : '全仓' }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="positionType" label="合约类型" align="center">
        <template #default="{ row }">
          <el-tag :type="row.positionType == 'SELL' ? 'danger' : 'success'">
            {{ row.positionType == 'SELL' ? '做空' : '做多' }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="symbolName" label="交易对" align="center" />
      <el-table-column prop="balance" label="仓位价值" align="center" />
      <el-table-column prop="volume" label="持币数" align="center" />
      <el-table-column prop="marketPrice" label="当前市价" align="center" />
      <el-table-column prop="buyPrice" label="买入市价" align="center" />
      <el-table-column prop="sellPrice" label="卖出市价" align="center">
        <template #default="{ row }">
          <span>{{ row.sellPrice ? row.sellPrice : '--' }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="closeType" label="清仓类型" align="center">
        <template #default="{ row }">
          <el-tag :type="closeTypeFormat(row.closeType).type">
            {{ closeTypeFormat(row.closeType).text }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="createTime" label="清仓时间" align="center" width="150">
        <template #default="{ row }">
          <span>{{ row.createTime ? row.createTime : '--' }}</span>
        </template>
      </el-table-column>
      <el-table-column label="盈亏" align="center">
        <template #default="{ row }">
          <p
            :class="[
              row.profitLoss >= 0
                ? 'text-[var(--el-color-success)]'
                : 'text-[var(--el-color-danger)]'
            ]"
          >
            {{ row.profitLoss ? row.profitLoss : '0.00' }}
          </p>
        </template>
      </el-table-column>
    </el-table>

    <div class="flex justify-center">
      <el-pagination
        class="mt-5"
        :current-page="form.pageNum + 1"
        small
        v-model:page-size="form.pageSize"
        :page-sizes="[10, 20, 50, 100]"
        background
        layout="total, sizes, prev, pager, next, jumper"
        :total="totalPages"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </div>
  </el-dialog>
</template>

<script setup lang="ts">
import { ref, reactive, watch } from 'vue'
import { queryBalance } from '../service'
import { closeTypeFormat } from '@/utils/format'

const props = defineProps({
  detailsVisible: {
    type: Boolean,
    default: false
  },
  userId: {
    type: Number,
    default: 0
  }
})
const emit = defineEmits(['close'])

const tableList: any = ref([])
const form = reactive({
  pageNum: 0,
  pageSize: 10
})
const totalPages = ref(0)

//详情列表
const getDetailsList = async () => {
  const res = await queryBalance({ ...form, userId: props.userId })
  tableList.value = res.data.list
  totalPages.value = res.data.totalCount
}

watch(
  () => props.detailsVisible,
  (val) => {
    if (val) getDetailsList()
  },
  { immediate: true, deep: true }
)

// 选择每页显示条数
const handleSizeChange = (val: number) => {
  form.pageSize = val
  getDetailsList()
}
// 点击每一页
const handleCurrentChange = (val: number) => {
  form.pageNum = val - 1
  getDetailsList()
}

const close = () => {
  emit('close')
}
</script>
