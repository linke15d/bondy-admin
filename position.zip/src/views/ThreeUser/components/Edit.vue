<template>
  <el-dialog
    :model-value="editVisible"
    :title="!flag ? '批量修改参数' : '修改参数'"
    width="400"
    center
    :before-close="close"
  >
    <el-form :model="saveData" size="small" :rules="rules" label-width="90" ref="ruleFormRef">
      <el-form-item label="已选择" v-if="!flag">
        <span class="text-red-500">{{ ids.length }}</span>
      </el-form-item>
      <el-form-item label="跟单系数" prop="multiple">
        <el-input
          v-model="saveData.multiple"
          @input="(val) => (saveData.multiple = val.replace(/[^0-9.]/g, ''))"
          placeholder="请输入跟单系数"
        />
      </el-form-item>
      <el-form-item label="免跟单下限" prop="lowerLimit">
        <el-input
          v-model="saveData.lowerLimit"
          @input="(val) => (saveData.lowerLimit = val.replace(/[^0-9.]/g, ''))"
          placeholder="请输入免跟单下限"
        />
      </el-form-item>
      <el-form-item label="免跟单上限" prop="upperLimit">
        <el-input
          v-model="saveData.upperLimit"
          @input="(val) => (saveData.upperLimit = val.replace(/[^0-9.]/g, ''))"
          placeholder="请输入免跟单上限"
        />
      </el-form-item>
    </el-form>

    <template #footer>
      <el-button size="small" @click="close">取消</el-button>
      <el-button size="small" type="primary" @click="onConfirm">确定</el-button>
    </template>
  </el-dialog>
</template>

<script setup lang="ts">
import { ref, reactive, watch } from 'vue'
import { upParam, upBatchParam } from '../service'
import { ElMessage } from 'element-plus'

const props = defineProps({
  editVisible: {
    type: Boolean,
    default: false
  },
  itemData: {
    type: Object,
    default: {}
  },
  ids: {
    type: Array,
    default: []
  },
  flag: {
    type: Boolean,
    default: false
  }
})
const emit = defineEmits(['close', 'success'])

const saveData = reactive({
  id: '',
  ids: [] as any,
  multiple: '',
  lowerLimit: '',
  upperLimit: ''
})
const rules = ref({
  multiple: [{ required: true, message: '跟单系数不能为空', trigger: 'blur' }],
  lowerLimit: [{ required: true, message: '免跟单下限不能为空', trigger: 'blur' }],
  upperLimit: [{ required: true, message: '免跟单上限不能为空', trigger: 'blur' }]
})
const ruleFormRef = ref()

watch(
  () => props.editVisible,
  (val) => {
    if (val) {
      saveData.id = ''
      saveData.ids = []
      saveData.multiple = ''
      saveData.lowerLimit = ''
      saveData.upperLimit = ''
    }
  },
  { immediate: true, deep: true }
)

watch(
  () => props.itemData,
  (val) => {
    if (val) {
      saveData.id = val.id
      saveData.multiple = val.multiple
      saveData.lowerLimit = val.lowerLimit
      saveData.upperLimit = val.upperLimit
    }
  },
  { immediate: true, deep: true }
)

const close = () => {
  ruleFormRef.value.resetFields()
  emit('close')
}

const onConfirm = async () => {
  await ruleFormRef.value.validate((vali, fields) => {
    if (!vali) {
      console.log('error submit!', fields)
    } else {
      const apiFunction = !props.flag ? upBatchParam : upParam

      let params = {}

      params = !props.flag
        ? {
            ids: props.ids,
            multiple: Number(saveData.multiple),
            lowerLimit: Number(saveData.lowerLimit),
            upperLimit: Number(saveData.upperLimit)
          }
        : {
            id: saveData.id,
            multiple: Number(saveData.multiple),
            lowerLimit: Number(saveData.lowerLimit),
            upperLimit: Number(saveData.upperLimit)
          }

      for (const i in params) {
        if (params[i] === '') {
          delete params[i]
        }
      }

      apiFunction(params).then((res) => {
        if (res.success) {
          ElMessage.success('操作成功')
          emit('success')
        }
      })
    }
  })
}
</script>
