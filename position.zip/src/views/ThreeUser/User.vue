<template>
  <div class="p-2">
    <ElCard>
      <el-row :gutter="20">
        <el-col :span="5">
          <el-form-item label="创建时间" size="small">
            <el-date-picker
              v-model="selectionDate"
              type="daterange"
              range-separator="至"
              start-placeholder="开始时间"
              end-placeholder="结束时间"
              format="YYYY-MM-DD"
              value-format="YYYY-MM-DD"
              @change="dateChange"
            />
          </el-form-item>
        </el-col>

        <el-col :span="5">
          <el-form-item label="三方会员UID" size="small">
            <el-input
              v-model="form.userId"
              placeholder="请输入三方会员UID"
              @input="(val) => (form.userId = val.replace(/[^0-9]/g, ''))"
            ></el-input>
          </el-form-item>
        </el-col>

        <el-col :span="5">
          <el-form-item>
            <ElButton type="primary" size="small" @click="onSearch">搜索</ElButton>
            <ElButton size="small" @click="onReset">重置</ElButton>
          </el-form-item>
        </el-col>
      </el-row>
    </ElCard>

    <ElCard class="my-4">
      <el-row class="mb-4 text-sm">
        <el-col :span="3">
          <ElButton type="primary" size="small" @click="onBatch">批量修改参数</ElButton>
        </el-col>
      </el-row>

      <el-table
        size="small"
        ref="refTable"
        :data="tableList"
        style="width: 100%"
        @selection-change="onSelectionChange"
        @sort-change="onSortChange"
      >
        <el-table-column type="selection" width="55" />
        <el-table-column prop="userId" label="三方会员UID" align="center" />
        <el-table-column label="持仓数" align="center">
          <template #default="{ row }">
            <span
              class="text-[var(--el-color-primary)] underline cursor-pointer"
              @click="toMonitor(row)"
            >
              {{ row.holdPosition }}
            </span>
          </template>
        </el-table-column>
        <el-table-column label="总资产" align="center">
          <template #default="{ row }">
            <p
              :class="[
                row.all >= 0 ? 'text-[var(--el-color-success)]' : 'text-[var(--el-color-danger)]'
              ]"
            >
              {{ row.all }}
            </p>
          </template>
        </el-table-column>
        <el-table-column label="可用资产" align="center">
          <template #default="{ row }">
            <p
              :class="[
                row.overNum >= 0
                  ? 'text-[var(--el-color-success)]'
                  : 'text-[var(--el-color-danger)]'
              ]"
            >
              {{ row.overNum }}
            </p>
          </template>
        </el-table-column>
        <el-table-column prop="lockNum" label="冻结资产" align="center" />
        <el-table-column label="累计盈亏" sortable align="center">
          <template #default="{ row }">
            <p
              :class="[
                row.balance >= 0
                  ? 'text-[var(--el-color-success)]'
                  : 'text-[var(--el-color-danger)]'
              ]"
            >
              {{ row.balance ? row.balance : '0.00' }}
            </p>
            <p class="text-[var(--el-color-primary)] cursor-pointer" @click="onDetails(row)">
              详情
            </p>
          </template>
        </el-table-column>
        <el-table-column label="跟单系数" align="center">
          <template #default="{ row }">
            <p>跟单系数：{{ row.multiple ? row.multiple : '0.00' }} </p>
            <p>免跟单下限：{{ row.lowerLimit ? row.lowerLimit : '0.00' }}</p>
            <p>免跟单上限：{{ row.upperLimit ? row.upperLimit : '0.00' }}</p>
          </template>
        </el-table-column>
        <el-table-column
          prop="createTime"
          label="创建时间"
          align="center"
          width="150"
        ></el-table-column>
        <el-table-column label="操作" align="center" fixed="right">
          <template #default="{ row }">
            <el-button type="warning" @click="onWrite(row)" size="small"> 修改参数 </el-button>
          </template>
        </el-table-column>
      </el-table>
    </ElCard>

    <ElCard>
      <el-pagination
        :current-page="form.pageNum + 1"
        small
        v-model:page-size="form.pageSize"
        :page-sizes="[10, 20, 50, 100]"
        background
        layout="total, sizes, prev, pager, next, jumper"
        :total="totalPages"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </ElCard>

    <Details :detailsVisible="detailsVisible" :userId="userId" @close="detailsVisible = false" />
    <Edit
      :flag="flag"
      :ids="ids"
      :editVisible="editVisible"
      :itemData="itemData"
      @close=";(editVisible = false), (itemData = {})"
      @success=";(editVisible = false), getList()"
    />
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
// import dayjs from 'dayjs'
import Details from './components/Details.vue'
import Edit from './components/Edit.vue'
import { clientQuery } from './service'

import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'

// const today = dayjs().format('YYYY-MM-DD')
const selectionDate = ref([])
const router = useRouter()

const form = reactive({
  userId: '',
  startTime: '',
  endTime: '',
  orderColumn: '',
  orderType: '',
  pageNum: 0,
  pageSize: 10
})
const tableList: any = ref([])

const totalPages = ref(0)
const detailsVisible = ref(false)
const editVisible = ref(false)
const itemData = ref({})
const userId = ref(0)
const ids: any = ref([])
const refTable = ref()
const flag = ref(true)

//排序
const onSortChange = (val) => {
  if (val.order == 'ascending') {
    form.orderType = 'ASC'
    form.orderColumn = 'balance'
  }
  if (val.order == 'descending') {
    form.orderType = 'DESC'
    form.orderColumn = 'balance'
  }
  if (val.order == null) {
    form.orderType = ''
    form.orderColumn = ''
  }
  getList()
}

//全选
const onSelectionChange = (val) => {
  ids.value = []
  if (val) {
    val.forEach((item) => {
      ids.value.push(item.id)
    })
  }
}

//批量修改参数
const onBatch = () => {
  if (!ids.value.length) return ElMessage.error('请先选择列表数据')
  flag.value = false
  editVisible.value = true
}

//跳转仓位监控
const toMonitor = (data) => {
  router.push({
    path: '/position/monitor',
    query: { userId: data.userId + '' }
  })
}

//详情
const onDetails = (data) => {
  userId.value = data.userId
  detailsVisible.value = true
}

//三方会员列表
const getList = async () => {
  const params = Object.assign({ ...form })
  params.userId = !params.userId.length ? '' : Number(params.userId)
  for (const i in params) {
    if (params[i] === '' || params[i] === null || params[i] === undefined) {
      delete params[i]
    }
  }
  const res = await clientQuery(params)
  tableList.value = res.data.list
  totalPages.value = res.data.totalCount
}

// 选择每页显示条数
const handleSizeChange = (val: number) => {
  form.pageSize = val
  getList()
}
// 点击每一页
const handleCurrentChange = (val: number) => {
  form.pageNum = val - 1
  getList()
}

//修改参数
const onWrite = (data) => {
  flag.value = true
  itemData.value = data
  editVisible.value = true
}

//选择时间
const dateChange = (val) => {
  form.startTime = val ? val[0] : ''
  form.endTime = val ? val[1] : ''
}

const onSearch = () => {
  form.pageNum = 0
  getList()
}

const onReset = () => {
  refTable.value.clearSort()
  selectionDate.value = []
  form.userId = ''
  form.startTime = ''
  form.endTime = ''
  form.orderColumn = ''
  form.orderType = ''
  form.pageNum = 0
  form.pageSize = 10
  getList()
}

onMounted(() => {
  getList()
})
</script>
