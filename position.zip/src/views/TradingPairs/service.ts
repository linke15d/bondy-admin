import request from '@/config/axios'

// 交易对列表
export const symbolQuery = (data): Promise<IResp> => {
  return request.post({ url: '/api/symbol/query', data })
}
// 禁用启用
export const symbolEnabled = (data): Promise<IResp> => {
  return request.post({ url: '/api/symbol/enabled', data })
}