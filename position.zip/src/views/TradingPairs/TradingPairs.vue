<template>
  <el-form size="small">
    <ElCard>
      <el-row :gutter="20">
        <el-col :span="4">
          <el-form-item label="交易对ID" size="small">
            <el-input
              v-model="form.symbolId"
              placeholder="请输入交易对ID"
              @input="(val) => (form.symbolId = val.replace(/[^0-9]/g, ''))"
            ></el-input>
          </el-form-item>
        </el-col>

        <el-col :span="4">
          <el-form-item label="交易对" size="small">
            <el-input v-model="form.symbolName" placeholder="请输入交易对"></el-input>
          </el-form-item>
        </el-col>

        <el-col :span="4">
          <el-form-item label="状态" size="small">
            <el-select v-model="form.enabled" class="w-full">
              <el-option label="全部" :value="null" />
              <el-option label="启用" :value="true" />
              <el-option label="停用" :value="false" />
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="5">
          <el-form-item>
            <ElButton type="primary" size="small" @click="onSearch">搜索</ElButton>
            <ElButton size="small" @click="onReset">重置</ElButton>
          </el-form-item>
        </el-col>
      </el-row>
    </ElCard>

    <ElCard class="my-5">
      <ElTable :data="tableList" ref="refTable" style="width: 100%" size="small">
        <ElTableColumn label="交易对ID" prop="symbolId" align="center" width="100" />
        <ElTableColumn label="交易对" prop="symbolName" align="center" />
        <ElTableColumn label="最大杠杆" prop="maxLeverage" align="center" />
        <ElTableColumn label="单张合约价值" prop="contractValue" align="center" />
        <ElTableColumn label="币安最小交易金额(u)" prop="minValue" align="center" />
        <ElTableColumn label="市场价" prop="marketPrice" align="center" />
        <ElTableColumn label="净头寸" prop="netPosition" align="center" />
        <ElTableColumn label="多头头寸" prop="rise" align="center" />
        <ElTableColumn label="空头头寸" prop="fall" align="center" />

        <ElTableColumn label="状态" align="center">
          <template #default="{ row }">
            <p
              :class="[
                row.enabled ? 'text-[var(--el-color-success)]' : 'text-[var(--el-color-danger)]'
              ]"
            >
              {{ row.enabled ? '启用' : '禁用' }}
            </p>
          </template>
        </ElTableColumn>

        <ElTableColumn label="操作" fixed="right" align="center">
          <template #default="{ row }">
            <el-popconfirm title="确认禁用吗?" @confirm="onEnabled(row)">
              <template #reference>
                <ElButton type="danger" size="small" v-if="row.enabled">禁用</ElButton>
              </template>
            </el-popconfirm>

            <el-popconfirm title="确认启用吗?" @confirm="onEnabled(row)">
              <template #reference>
                <ElButton type="success" size="small" v-if="!row.enabled">启用</ElButton>
              </template>
            </el-popconfirm>
          </template>
        </ElTableColumn>
      </ElTable>
    </ElCard>

    <ElCard class="box-card">
      <el-pagination
        :current-page="form.pageNum + 1"
        small
        v-model:page-size="form.pageSize"
        :page-sizes="[10, 20, 50, 100]"
        background
        layout="total, sizes, prev, pager, next, jumper"
        :total="totalPages"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </ElCard>
  </el-form>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { symbolQuery, symbolEnabled } from './service'
import { ElButton, ElMessage } from 'element-plus'

const form = reactive({
  pageNum: 0,
  pageSize: 10,
  symbolId: '',
  symbolName: '',
  enabled: null
})
const selectionDate = ref([])
const tableList = ref<any>([])
const totalPages = ref(0)
const refTable = ref()

// 选择每页显示条数
const handleSizeChange = (val: number) => {
  form.pageSize = val
  getSymbolQuery()
}
// 点击每一页
const handleCurrentChange = (val: number) => {
  form.pageNum = val - 1
  getSymbolQuery()
}

//禁用启用
const onEnabled = async (data) => {
  await symbolEnabled({ id: data.id, enabled: !data.enabled })
  ElMessage.success('操作成功')
  getSymbolQuery()
}

//获取列表
const getSymbolQuery = async () => {
  const params = Object.assign({ ...form })
  for (const i in params) {
    if (params[i] === '' || params[i] === null) {
      delete params[i]
    }
  }
  const res = await symbolQuery(params)
  tableList.value = res.data.list
  totalPages.value = res.data.totalCount
}

const onSearch = () => {
  form.pageNum = 0
  getSymbolQuery()
}
const onReset = () => {
  selectionDate.value = []
  form.pageNum = 0
  form.pageSize = 10
  form.symbolId = ''
  form.symbolName = ''
  form.enabled = null
  getSymbolQuery()
}

onMounted(() => {
  getSymbolQuery()
})
</script>
