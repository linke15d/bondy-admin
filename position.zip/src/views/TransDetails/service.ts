import request from '@/config/axios'

//交易明细列表查询
export const tradeQuery = (data): Promise<IResp> => {
  return request.post({ url: '/api/binance/trade/query', data })
}
//交易明细统计
export const tradeSummary = (data): Promise<IResp> => {
  return request.post({ url: '/api/binance/trade/summary', data })
}