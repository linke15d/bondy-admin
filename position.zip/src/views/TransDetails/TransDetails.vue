<template>
  <div class="p-2">
    <ElCard>
      <el-row :gutter="20">
        <el-col :span="5">
          <el-form-item label="交易时间" size="small">
            <el-date-picker
              v-model="selectionDate"
              type="daterange"
              range-separator="至"
              start-placeholder="开始时间"
              end-placeholder="结束时间"
              format="YYYY-MM-DD"
              value-format="YYYY-MM-DD"
              @change="dateChange"
            />
          </el-form-item>
        </el-col>

        <el-col :span="5">
          <el-form-item label="交易ID" size="small">
            <el-input
              v-model="form.orderId"
              placeholder="请输入交易ID"
              @input="(val) => (form.orderId = val.replace(/[^0-9]/g, ''))"
            ></el-input>
          </el-form-item>
        </el-col>

        <el-col :span="4">
          <el-form-item label="账号名称" size="small">
            <el-select v-model="form.accountId" class="w-full" placeholder="请选择账号名称">
              <el-option
                v-for="(item, index) in binanceAccountList"
                :key="index"
                :label="item.accountId"
                :value="item.id"
              />
            </el-select>
          </el-form-item>
        </el-col>

        <el-col :span="5">
          <el-form-item label="三方仓位ID" size="small">
            <el-input
              v-model="form.positionId"
              placeholder="请输入三方仓位ID"
              @input="(val) => (form.positionId = val.replace(/[^0-9]/g, ''))"
            ></el-input>
          </el-form-item>
        </el-col>

        <el-col :span="5">
          <el-form-item>
            <ElButton type="primary" size="small" @click="onSearch">搜索</ElButton>
            <ElButton size="small" @click="onReset">重置</ElButton>
          </el-form-item>
        </el-col>
      </el-row>
    </ElCard>

    <ElCard class="my-4">
      <el-row class="mb-4">
        <span>
          三方盈亏:
          <span
            :class="[
              summaryData.profit2 < 0
                ? 'text-[var(--el-color-danger)]'
                : 'text-[var(--el-color-success)]'
            ]"
          >
            {{ summaryData.profit2 ? summaryData.profit2 : 0 }}
          </span>
        </span>

        <span class="ml-5">
          币安盈亏：
          <span
            :class="[
              summaryData.profit1 < 0
                ? 'text-[var(--el-color-danger)]'
                : 'text-[var(--el-color-success)]'
            ]"
          >
            {{ summaryData.profit1 ? summaryData.profit1 : 0 }}
          </span>
        </span>
        <!-- <el-form-item label="显示跟单">
          <el-popconfirm :title="switchTitle" @confirm="confirm" @cancel="cancel">
            <template #reference>
              <el-switch
                v-model="switchVal"
                @change="onSwitchChange"
                style="--el-switch-on-color: #13ce66; --el-switch-off-color: #ff4949"
              />
            </template>
          </el-popconfirm>
        </el-form-item> -->
      </el-row>

      <el-table
        size="small"
        ref="multipleTable"
        :data="tableList"
        :row-class-name="tableRowClassName"
        style="width: 100%"
      >
        <el-table-column label="交易时间" align="center" width="300" fixed="left">
          <template #default="{ row }">
            <span>{{ `${row.tradeTime2} / ${row.tradeTime1}` }}</span>
          </template>
        </el-table-column>
        <el-table-column label="交易ID" align="center" width="300" show-overflow-tooltip>
          <template #default="{ row }">
            <span>{{ `${row.orderNo2} / ${row.orderNo1}` }}</span>
          </template>
        </el-table-column>
        <el-table-column label="仓位ID" align="center" width="150">
          <template #default="{ row }">
            <span>{{ `${row.positionId2} / ${row.positionId1}` }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="symbol" label="交易对" align="center" />
        <el-table-column label="交易类型" align="center">
          <template #default="{ row }">
            <el-tag :type="sideFormat(row.side).type">
              {{ sideFormat(row.side).text }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="账号名称" align="center" width="120">
          <template #default="{ row }">
            <span>{{ `${row.accountName2} / ${row.accountName1}` }}</span>
          </template>
        </el-table-column>
        <ElTableColumn label="保证金模式" align="center" width="120">
          <template #default="{ row }">
            <div>
              <el-tag :type="marginTypeFormat(row.marginType2).type">
                {{ marginTypeFormat(row.marginType2).text }}
              </el-tag>
              /
              <el-tag :type="marginTypeFormat(row.marginType1).type">
                {{ marginTypeFormat(row.marginType1).text }}
              </el-tag>
            </div>
          </template>
        </ElTableColumn>
        <el-table-column label="合约类型" align="center" width="120">
          <template #default="{ row }">
            <div>
              <el-tag :type="positionSideFormat(row.positionSide2).type">
                {{ positionSideFormat(row.positionSide2).text }}
              </el-tag>
              /
              <el-tag :type="positionSideFormat(row.positionSide1).type">
                {{ positionSideFormat(row.positionSide1).text }}
              </el-tag>
            </div>
          </template>
        </el-table-column>
        <ElTableColumn label="杠杆倍数" align="center">
          <template #default="{ row }">
            <span>{{ `${row.leverage2} / ${row.leverage1}` }}</span>
          </template>
        </ElTableColumn>
        <el-table-column label="交易价格" align="center" width="180">
          <template #default="{ row }">
            <span>{{ `${row.price2} / ${row.price1}` }}</span>
          </template>
        </el-table-column>
        <el-table-column label="交易数量" align="center" width="120">
          <template #default="{ row }">
            <span>{{ `${row.executedQty2} / ${row.executedQty1}` }}</span>
          </template>
        </el-table-column>
        <!-- <el-table-column prop="beforeBalance" label="交易前余额" align="center">
          <template #default="{ row }">
            <span
              :class="[
                row.beforeBalance >= 0
                  ? 'text-[var(--el-color-success)]'
                  : 'text-[var(--el-color-danger)]'
              ]"
            >
              {{ row.beforeBalance ? row.beforeBalance : '0.00' }}
            </span>
          </template>
        </el-table-column> -->
        <el-table-column prop="cumQuote" label="盈亏金额" align="center" width="220">
          <template #default="{ row }">
            <span
              :class="[
                row.profit2 < 0 ? 'text-[var(--el-color-danger)]' : 'text-[var(--el-color-success)]'
              ]"
            >
              {{ row.profit2 ? row.profit2 : '0.00' }}
            </span>
            /
            <span
              :class="[
                row.profit1 < 0 ? 'text-[var(--el-color-danger)]' : 'text-[var(--el-color-success)]'
              ]"
            >
              {{ row.profit1 ? row.profit1 : '0.00' }}
            </span>
          </template>
        </el-table-column>
        <!-- <el-table-column prop="afterBalance" label="交易后余额" align="center">
          <template #default="{ row }">
            <span
              :class="[
                row.afterBalance >= 0
                  ? 'text-[var(--el-color-success)]'
                  : 'text-[var(--el-color-danger)]'
              ]"
            >
              {{ row.afterBalance ? row.afterBalance : '0.00' }}
            </span>
          </template>
        </el-table-column> -->
      </el-table>
    </ElCard>

    <ElCard>
      <el-pagination
        :current-page="form.pageNum + 1"
        small
        v-model:page-size="form.pageSize"
        :page-sizes="[10, 20, 50, 100]"
        background
        layout="total, sizes, prev, pager, next, jumper"
        :total="totalPages"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </ElCard>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { tradeQuery, tradeSummary } from './service'
import { sideFormat, positionSideFormat, marginTypeFormat } from '@/utils/format'
import { accountList } from '../BinanceAccount/service'

const selectionDate = ref([])
const tableList: any = ref([])
const totalPages = ref(0)
// const switchVal = ref(false)
// const switchTitle = ref('')
const binanceAccountList: any = ref([])
const summaryData: any = ref({})

const form = reactive({
  startTime: '',
  endTime: '',
  orderId: '',
  accountId: '',
  // showFollowOrder: switchVal.value,
  positionId: '',
  pageNum: 0,
  pageSize: 10
})

//统计
const getTradeSummary = async () => {
  const params = Object.assign({ ...form })
  params.orderId = !params.orderId.length ? '' : Number(params.orderId)
  for (const i in params) {
    if (params[i] === '' || params[i] === null || params[i] === undefined) {
      delete params[i]
    }
  }
  const res = await tradeSummary(params)
  summaryData.value = res.data
}

//为三方跟单添加classname
const tableRowClassName = ({ row }) => {
  if (row.tradeOwner == 2) return 'warning-row'
  return ''
}

//获取币安账号列表
const getAccountList = async () => {
  const res = await accountList({})
  binanceAccountList.value = res.data.list
}

//跟单开关
// const confirm = async () => {
//   form.showFollowOrder = !form.showFollowOrder
//   getTradeList()
// }
// const cancel = () => {
//   switchVal.value = !switchVal.value
// }
// const onSwitchChange = (val) => {
//   switchTitle.value = val ? '确定显示跟单吗？' : '确定取消显示跟单吗？'
// }

//选择时间
const dateChange = (val) => {
  form.startTime = val ? val[0] : ''
  form.endTime = val ? val[1] : ''
}

//获取列表
const getTradeList = async () => {
  const params = Object.assign({ ...form })
  params.orderId = !params.orderId.length ? '' : Number(params.orderId)
  for (const i in params) {
    if (params[i] === '' || params[i] === null || params[i] === undefined) {
      delete params[i]
    }
  }
  const res = await tradeQuery(params)
  tableList.value = res.data.list
  totalPages.value = res.data.totalCount
}

// 选择每页显示条数
const handleSizeChange = (val: number) => {
  form.pageSize = val
  getTradeList()
  getTradeSummary()
}
// 点击每一页
const handleCurrentChange = (val: number) => {
  form.pageNum = val - 1
  getTradeList()
  getTradeSummary()
}

const onSearch = () => {
  form.pageNum = 0
  getTradeList()
  getTradeSummary()
}

const onReset = () => {
  selectionDate.value = []
  form.orderId = ''
  form.accountId = ''
  form.startTime = ''
  form.endTime = ''
  form.positionId = ''
  form.pageNum = 0
  form.pageSize = 10
  getTradeList()
  getTradeSummary()
}

onMounted(() => {
  getAccountList()
  getTradeList()
  getTradeSummary()
})
</script>

<style lang="less">
.warning-row {
  --el-table-tr-bg-color: var(--el-color-warning-light-9);
}
</style>
