<template>
  <div class="p-2">
    <ElCard class="mb-4">
      <el-row justify="space-between">
        <el-form-item>
          <ElButton type="success" size="small" @click="onWrite(null)"> 新增 </ElButton>
        </el-form-item>
      </el-row>

      <el-table size="small" ref="multipleTable" :data="tableList" style="width: 100%">
        <ElTableColumn prop="accountId" label="账号名称" align="center" />
        <ElTableColumn prop="balance" label="余额" align="center">
          <template #default="{ row }">
            <span
              :class="[
                row.balance >= 0
                  ? 'text-[var(--el-color-success)]'
                  : 'text-[var(--el-color-danger)]'
              ]"
            >
              {{ row.balance ? row.balance : '0.00' }}
            </span>
          </template>
        </ElTableColumn>
        <ElTableColumn prop="positionSize" label="持仓数" align="center">
          <template #default="{ row }">
            <span>{{ row.positionSize ? row.positionSize : 0 }}</span>
          </template>
        </ElTableColumn>
        <ElTableColumn prop="profit" label="累计盈亏" align="center">
          <template #default="{ row }">
            <span
              :class="[
                row.profit >= 0 ? 'text-[var(--el-color-success)]' : 'text-[var(--el-color-danger)]'
              ]"
            >
              {{ row.profit ? row.profit : '0.00' }}
            </span>
          </template>
        </ElTableColumn>
        <ElTableColumn label="保证金模式" prop="marginType" align="center">
          <template #default="{ row }">
            <el-tag :type="marginTypeFormat(row.marginType).type">
              {{ marginTypeFormat(row.marginType).text }}
            </el-tag>
          </template>
        </ElTableColumn>
        <ElTableColumn label="状态" align="center">
          <template #default="{ row }">
            <el-tag :type="row.status ? 'success' : 'danger'">
              {{ row.status ? '启用中' : '已停用' }}
            </el-tag>
          </template>
        </ElTableColumn>
        <ElTableColumn prop="remark" label="备注" align="center">
          <template #default="{ row }">
            <span>{{ row.remark ? row.remark : '--' }}</span>
          </template>
        </ElTableColumn>
        <ElTableColumn prop="" label="操作" align="center" width="280px" fixed="right">
          <template #default="{ row }">
            <el-button type="warning" @click="onWrite(row)" size="small"> 编辑 </el-button>
            <el-popconfirm title="确认一键平仓吗?" @confirm="onClosing(row)">
              <template #reference>
                <ElButton type="success" size="small" v-if="!row.closeStatus"> 一键平仓</ElButton>
              </template>
            </el-popconfirm>
          </template>
        </ElTableColumn>
      </el-table>
    </ElCard>

    <ElCard>
      <el-pagination
        :current-page="form.pageNum + 1"
        small
        v-model:page-size="form.pageSize"
        :page-sizes="[10, 20, 50, 100]"
        background
        layout="total, sizes, prev, pager, next, jumper"
        :total="totalPages"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </ElCard>

    <AddAccount
      :userType="userType"
      :dialogVisible="dialogVisible"
      :editData="editData"
      @success="getAccountList()"
      @close=";(dialogVisible = false), (editData = {})"
    />
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { accountQuery, accountClose } from './service'
import AddAccount from './components/AddAccount.vue'
import { marginTypeFormat } from '@/utils/format'
import { ElMessage } from 'element-plus'

const form = ref({
  pageNum: 0,
  pageSize: 10
})
const tableList = ref([])
const totalPages = ref(0)
const editData = ref({})
const dialogVisible = ref(false)
const userType = ref('')

//一键平仓
const onClosing = async (data) => {
  await accountClose({ id: data.id })
  ElMessage.success('操作成功')
  getAccountList()
}

//新增编辑
const onWrite = (data) => {
  dialogVisible.value = true
  editData.value = data ? data : {}
  userType.value = data ? data.userType : ''
}

//获取用户列表
const getAccountList = async () => {
  const params = Object.assign({ ...form.value })
  for (const i in params) {
    if (params[i] === '' || params[i] === undefined || params[i] === null) {
      delete params[i]
    }
  }
  const res = await accountQuery(params)
  tableList.value = res.data.list
  totalPages.value = res.data.totalCount
}

// 选择每页显示条数
const handleSizeChange = (val: number) => {
  form.value.pageSize = val
  getAccountList()
}
// 点击每一页
const handleCurrentChange = (val: number) => {
  form.value.pageNum = val - 1
  getAccountList()
}

onMounted(() => {
  getAccountList()
})
</script>
