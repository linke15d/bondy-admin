<template>
  <el-dialog
    :model-value="dialogVisible"
    :title="editData.id ? '编辑账号' : '新增账号'"
    width="400"
    center
    :before-close="onClose"
  >
    <el-form :model="saveData" size="small" :rules="rules" label-width="90" ref="ruleFormRef">
      <el-form-item label="币安账号" prop="accountId">
        <el-input
          v-model="saveData.accountId"
          :disabled="editData.id ? true : false"
          placeholder="请输入币安账号"
        />
      </el-form-item>
      <el-form-item label="Api-Key" prop="apiKey">
        <el-input v-model="saveData.apiKey" placeholder="请输入Api-Key" />
      </el-form-item>
      <el-form-item label="API-Secret" prop="apiSecret">
        <el-input v-model="saveData.apiSecret" placeholder="请输入API-Secret" />
      </el-form-item>
      <el-form-item label="保证金模式" prop="marginType">
        <el-select placeholder="请选择保证金模式" class="w-full" v-model="saveData.marginType">
          <el-option label="全仓" value="CROSSED"></el-option>
          <el-option label="逐仓" value="ISOLATED"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="状态" prop="status">
        <el-radio-group v-model="saveData.status" class="!flex w-full">
          <el-radio :label="true"> 启用 </el-radio>
          <el-radio :label="false" class="danger"> 停用 </el-radio>
        </el-radio-group>
      </el-form-item>

      <el-form-item label="备注">
        <el-input
          v-model="saveData.remark"
          type="textarea"
          :rows="3"
          maxlength="30"
          placeholder="请输入备注,30字内"
        />
      </el-form-item>
    </el-form>

    <template #footer>
      <el-button size="small" @click="onClose">取消</el-button>
      <el-button size="small" type="primary" @click="onSubmitData">确认</el-button>
    </template>
  </el-dialog>
</template>

<script setup lang="ts">
import { ref, watch } from 'vue'
import { ElMessage } from 'element-plus'
import { accountCreate, accountUpdate } from '../service'

const emit = defineEmits(['close', 'success', 'getOrg'])
const props = defineProps({
  dialogVisible: {
    type: Boolean,
    default: false
  },
  editData: {
    type: Object,
    default: {}
  },
  userType: {
    type: String,
    default: ''
  }
})

const rules = ref({
  accountId: [{ required: true, message: '币安账号不能为空', trigger: 'blur' }],
  apiKey: [{ required: true, message: 'Api-Key不能为空', trigger: 'blur' }],
  apiSecret: [{ required: true, message: 'API-Secret不能为空', trigger: 'blur' }],
  status: [{ required: true, message: '状态不能为空', trigger: 'blur' }],
  marginType: [{ required: true, message: '保证金模式不能为空', trigger: 'blur' }]
})

const ruleFormRef = ref()

const saveData = ref<any>({
  id: '',
  accountId: '',
  apiKey: '',
  apiSecret: '',
  marginType: '',
  status: true,
  remark: ''
})

watch(
  () => props.editData,
  (val) => {
    if (val && val.id) {
      saveData.value.id = val.id
      saveData.value.accountId = val.accountId
      saveData.value.apiKey = val.apiKey
      saveData.value.apiSecret = val.apiSecret
      saveData.value.marginType = val.marginType
      saveData.value.status = val.status
      saveData.value.remark = val.remark
    } else {
      saveData.value = {
        id: '',
        accountId: '',
        apiKey: '',
        apiSecret: '',
        marginType: '',
        status: true,
        remark: ''
      }
    }
  },
  { immediate: true, deep: true }
)

const onSubmitData = async () => {
  await ruleFormRef.value.validate((vali, fields) => {
    if (!vali) {
      console.log('error submit!', fields)
    } else {
      try {
        let params: any = {}

        const orgApi = saveData.value.id ? accountUpdate : accountCreate

        params = Object.assign({ ...saveData.value })

        for (const i in params) {
          if (
            params[i] === '' ||
            params[i] === undefined ||
            params[i] === null ||
            params[i] === 'xxxxxxxx'
          ) {
            delete params[i]
          }
        }

        orgApi(params).then((res) => {
          if (res.success) {
            ElMessage.success('操作成功')
            emit('success')
            emit('close')
          }
        })
      } catch (error) {
        console.log(error)
      }
    }
  })
}

const onClose = () => {
  ruleFormRef.value.resetFields()
  emit('close')
}
</script>

<style>
.danger {
  .el-radio__input.is-checked .el-radio__inner {
    border-color: var(--el-color-danger);
    background: var(--el-color-danger);
  }
  .el-radio__input.is-checked + .el-radio__label {
    color: var(--el-color-danger);
  }
}
</style>
