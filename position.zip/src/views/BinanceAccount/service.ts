import request from '@/config/axios'

//列表查询
export const accountQuery = (data): Promise<IResp> => {
  return request.post({ url: '/api/binance/account/query', data })
}
//列表查询-无分页
export const accountList = (data): Promise<IResp> => {
  return request.post({ url: '/api/binance/account/list', data })
}
//新增
export const accountCreate = (data): Promise<IResp> => {
  return request.post({ url: '/api/binance/account/create', data })
}
//编辑
export const accountUpdate = (data): Promise<IResp> => {
  return request.post({ url: '/api/binance/account/update', data })
}
//删除
export const accountRemove = (data): Promise<IResp> => {
  return request.post({ url: '/api/binance/account/remove', data })
}
//一键平仓
export const accountClose = (data): Promise<IResp> => {
  return request.post({ url: '/api/binance/account/close', data })
}
