# 环境
VITE_NODE_ENV=production

# 接口地址
VITE_API_BASEURL=/

# 接口前缀
VITE_API_BASEPATH=pro

# 打包路径
VITE_BASE_PATH=/

# 是否删除debugger
VITE_DROP_DEBUGGER=true

# 是否删除console.log
VITE_DROP_CONSOLE=true

# 是否sourcemap
VITE_SOURCEMAP=false

# 输出路径
VITE_OUT_DIR=dist

# 标题
VITE_APP_TITLE='仓位后台管理系统'
